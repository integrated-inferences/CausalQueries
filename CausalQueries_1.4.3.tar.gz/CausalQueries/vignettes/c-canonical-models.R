## ----include = FALSE---------------------------------------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.path = ""
)

if(!requireNamespace("estimatr", quietly = TRUE)) {
  install.packages("estimatr")
}




## ----setup, warning = FALSE, message = FALSE---------------------------------------------------------------------------------------------------------------------

library(CausalQueries)
library(dplyr)
library(knitr)
library(estimatr)

options(mc.cores = 2)
set.seed(1)


## ----csimple, out.width = "50%", fig.cap = "Simple experiment"---------------------------------------------------------------------------------------------------
model <- make_model("X -> Y")
model |> plot()


## ----csimpleq, fig.cap = "Simple experiment query"---------------------------------------------------------------------------------------------------------------
model <- model |>
  set_parameters(nodal_type = c("10", "01"), parameters = c(.1, .6))

data <- model |>
  make_data(n = 5000)

model |>
  update_model(data, refresh = 0, iter = 5000) |>

  query_model(queries =
                list(ATE = "Y[X=1] - Y[X=0]",
                     POC = "Y[X=1] - Y[X=0] :|: X==1 & Y==1"),
              using = c("parameters", "priors", "posteriors")) |>

  plot()


## ----cconfounded, out.width = "75%", fig.cap = "Confounded model"------------------------------------------------------------------------------------------------
model <- make_model("X -> Y; X <-> Y")

model |> plot(x_coord = 0:1, y_coord = 1:0)


## ----cconfoundedq, fig.cap = "Confounded model query"------------------------------------------------------------------------------------------------------------
model <- model |>
  set_parameters(nodal_type = "01", parameters = .7)

data <- model |>
  make_data(n = 5000)

model |>
  update_model(data, refresh = 0, iter = 5000) |>

  query_model(queries =
                list(ATE = "Y[X=1] - Y[X=0]",
                     POC = "Y[X=1] - Y[X=0] :|: X==1 & Y==1"),
              using = c("parameters", "priors", "posteriors")) |>

  plot()


## ----cchain, out.width = "75%", fig.cap = "Chain model"----------------------------------------------------------------------------------------------------------
model <- make_model("Z -> X -> Y")
model |> plot()


## ----cchainq, fig.cap = "Chain model query"----------------------------------------------------------------------------------------------------------------------
model <- model |>
  set_parameters(param_names = c("X.10", "X.01", "Y.10", "Y.01"),
                 parameters = c(0.05, .85, .05, .85))

data <- model |>
  make_data(n = 5000)

model |>
  update_model(data, refresh = 0, iter = 5000) |>

  query_model(query = list("Y[Z=1] - Y[Z=0]"),
              given = c("", "Z==1 & Y==1", "Z==1 & Y==1 & X==0", "Z==1 & Y==1 & X==1"),
              using = c("parameters", "posteriors")) |>

  plot()


## ----civ, fig.cap = "IV model with exclusion restriction satisfied", out.width = "75%"---------------------------------------------------------------------------
# Model with exclusion restriction and monotonicity
model <- make_model("Z -> X -> Y; X <-> Y") |>
  set_restrictions(decreasing('Z', 'X'))  # monotonicity restriction


# Adding parameters for data generation
model <- model |>
  set_parameters(param_names = c("Y.10_X.01", "Y.01_X.01"),
                 parameters = c(0, .75))     # complier effect

model |> plot(x_coord = c(0,1,0), y_coord = 2:0)


## ----civq1, fig.cap = "IV inferences I"--------------------------------------------------------------------------------------------------------------------------

data <- make_data(model, 4000)

model |>

  update_model(data, refresh = 0, iter = 5000) |>

  query_model(
    query = list(
      ATE = "Y[X=1] - Y[X=0]",
      LATE= "Y[X=1] - Y[X=0] :|: X[Z=1] > X[Z=0]", # ATE for compliers
      PoC = "Y[X=1] - Y[X=0] :|: X==1 & Y==1",    # ATE for units with X=Y-1
      PoCC = "Y[X=1] - Y[X=0] :|: X==1 & Y==1 & (X[Z=1] > X[Z=0])"),    # ATE for units with X=Y-1
    using = c("posteriors", "parameters"),
    cred = 99) |>

  plot()


## ----civ2, fig.cap = "Exclusion restriction not satisfied", out.width = "75%"------------------------------------------------------------------------------------
model <- make_model("Z -> X -> Y <- Z; X <-> Y")
model |> plot(x_coord = c(0,1,0), y_coord = 2:0)


## ----civq2, fig.cap = "IV inferences II"-------------------------------------------------------------------------------------------------------------------------

model |>

  update_model(data, refresh = 0, iter = 5000) |>

  query_model(
    query = list(
      ATE = "Y[X=1] - Y[X=0]",
      LATE= "Y[X=1] - Y[X=0] :|: X[Z=1] > X[Z=0]", # ATE for compliers
      PoC = "Y[X=1] - Y[X=0] :|: X==1 & Y==1",    # ATE for units with X=Y-1
      PoCC = "Y[X=1] - Y[X=0] :|: X==1 & Y==1 & (X[Z=1] > X[Z=0])"), # ATE for compliers with X=Y-1
    using = c("posteriors"),
    cred = 99
) |>

  plot()



## ----cmed, out.width = "75%", fig.cap = "Mediation model with sequential ignorability satisfied"-----------------------------------------------------------------
model <- make_model("Z -> X -> Y <- Z")

model |> plot(x_coord = c(0,1,0), y_coord = 2:0)



## ----cmedq, fig.cap = "Mediation model query"--------------------------------------------------------------------------------------------------------------------

model <-
  make_model("Z -> X -> Y <- Z") |>
  set_parameters(nodal_type = c("00", "10"), parameters = c(0, .5)) |>
  set_parameters(nodal_type = "0001", parameters = .5)

data <- model |> make_data(n = 2000)

queries <- list(
  `ATE Z -> X` = "X[Z=1] - X[Z=0]",
  `ATE Z -> Y` = "Y[Z=1] - Y[Z=0]",
  `ATE X -> Y` = "Y[X=1] - Y[X=0]",
  `Direct (Z=1)` = "Y[Z = 1, X = X[Z=1]] - Y[Z = 0, X = X[Z=1]]",
  `Direct (Z=0)` = "Y[Z = 1, X = X[Z=0]] - Y[Z = 0, X = X[Z=0]]",
  `Indirect (Z=1)` = "Y[Z = 1, X = X[Z=1]] - Y[Z = 1, X = X[Z=0]]",
  `Indirect (Z=0)` = "Y[Z = 0, X = X[Z=1]] - Y[Z = 0, X = X[Z=0]]"
)

model |>
  update_model(data, refresh = 0, iter = 5000)  |>

  query_model(
    query = queries,
    cred = 99,
    using = c("parameters", "posteriors")) |>

  plot()


## ----cmed2, fig.cap = "Mediation model without sequential ignorability"------------------------------------------------------------------------------------------
model <- make_model("Z -> X -> Y <- Z; X <-> Y")  |>
  set_parameters(nodal_type = c("00", "10"), parameters = c(0, .5)) |>
  set_parameters(nodal_type = "0001", parameters = .5)

model |> plot(x_coord = c(0,1,0), y_coord = 2:0)


## ----cmed2q, fig.cap = "Querying mediation model without sequential ignorability"--------------------------------------------------------------------------------

  model |>

  update_model(data, iter = 5000) |>

  query_model(
    query = queries,
    cred = 99,
    using = c("parameters", "posteriors")
    ) |>

  plot()


## ----cnap, fig.out = "75%", fig.cap = "Napkin model"-------------------------------------------------------------------------------------------------------------
model <- make_model("W->Z->X->Y; W <-> X; W <-> Y")
plot(model)


## ----------------------------------------------------------------------------------------------------------------------------------------------------------------
model <- model |>
  set_parameters(param_name = "Y.10_W.0", parameters = .6) |>
  set_parameters(param_name = "Y.11_W.1", parameters = .9) |>
  set_parameters(param_name = "X.11_W.1", parameters = .9)



## ----results = 'asis'--------------------------------------------------------------------------------------------------------------------------------------------
data <- make_data(model, n = 5000, using = "parameters")

 estimatr::lm_robust(Y ~ X, data = data)  |>
   tidy() |>
   kable(digits = 2)



## ----cnapq, fig.cap = "Napkin model queries"---------------------------------------------------------------------------------------------------------------------


model |>
  update_model(data, refresh = 0, iter = 6000) |>
  query_model(
    list(
      ATE = "Y[X=1] - Y[X=0]",
      PoC = "Y[X=1] - Y[X=0] :|: X==1 & Y==1"),
    using = c("posteriors", "priors", "parameters")) |>
  plot()



## ----------------------------------------------------------------------------------------------------------------------------------------------------------------
model <- make_model("Z <- U1 -> Y; Z <- U2 -> X; X -> Y")


## ----cmbias, fig.out = "75%", fig.cap = "M bias model"-----------------------------------------------------------------------------------------------------------
model <- model |>
  set_parameters(param_name = "Y.0101", parameters = .8) |>
  set_parameters(param_name = "Z.0001", parameters = .8) |>
  set_parameters(param_name = "X.01", parameters = .8)


plot(model)




## ----results = 'asis'--------------------------------------------------------------------------------------------------------------------------------------------
data <- model |> make_data(n = 1000)


list(
  `no controls` = estimatr::lm_robust(Y ~ X, data = data),
  `with controls` = estimatr::lm_robust(Y ~ X + Z, data = data)
) |>
   lapply(tidy) |> bind_rows(.id = "Model") |>   filter(term =="X") |>
  kable(digits = 2, caption = "Estimation with and without controls")



## ----cmbiasq, fig.cap = "Querying a model with M bias"-----------------------------------------------------------------------------------------------------------

list(
  `Using Z` = model |> update_model(data, iter = 5000),
  `Ignoring Z` = model |> update_model(data |> dplyr::select(-Z), iter = 5000))|>

  query_model(
    list(
      "Y[X=1] - Y[X=0]",
      "Y[X=1] - Y[X=0] :|: X==1 & Y==1"),
    using = c("parameters", "priors",  "posteriors")) |>

  plot()


