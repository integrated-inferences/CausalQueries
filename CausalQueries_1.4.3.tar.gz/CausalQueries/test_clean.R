# Simple test to verify the cleaned Stan model works correctly
test_clean_stan <- function() {
  
  # Create model with confounding
  model <- make_model("X -> M -> Y; X <-> Y")
  
  # Generate small test dataset
  set.seed(123)
  data <- make_data(model, n = 10, param_type = "prior_draw")
  data_compact <- collapse_data(data, model)
  
  cat("Testing cleaned Stan model...\n")
  cat("Model:", model$statement, "\n")
  cat("Data events:", nrow(data_compact), "\n\n")
  
  # Run model
  model_fit <- update_model(
    model, 
    data = data_compact,
    keep_fit = TRUE,
    iter = 500,
    chains = 1
  )
  
  # Check if it ran successfully
  if (!is.null(model_fit$stan_objects$stanfit)) {
    cat("✓ SUCCESS: Stan model ran successfully\n")
    
    # Check for any warnings
    warnings <- model_fit$stan_objects$stan_warnings
    if (length(warnings) > 0) {
      cat("Warnings:", length(warnings), "\n")
    } else {
      cat("No warnings\n")
    }
    
    # Check posterior distribution
    if (!is.null(model_fit$posterior_distribution)) {
      cat("✓ Posterior distribution computed successfully\n")
    }
    
    cat("\nModel is ready for production use!\n")
    
    return(TRUE)
  } else {
    cat("✗ FAIL: Stan model failed to run\n")
    return(FALSE)
  }
}

# Run the test
test_clean_stan()
